import java.util.*;
public class Main{
    public static void main(String args[]){
        Scanner ps = new Scanner(System.in);
        String s = ps.next(),h="",j="";
        char ch;
        for(int i = 0 ;i<s.length();i++){
            ch = s.charAt(i);
            if(i==0){
                h = Character. toString(ch);
                j = h.toUpperCase();
                System.out.print(j+"");
            }else
            System.out.print(ch);
        }
    }
}
